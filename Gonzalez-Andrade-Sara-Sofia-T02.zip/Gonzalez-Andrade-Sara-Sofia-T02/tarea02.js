//El ciclo de vida de una página HTML tiene tres eventos importantes:
// DOMContentLoaded – el navegador HTML está completamente cargado y el árbol DOM está construido, 
// pero es posible que los recursos externos como <img> y hojas de estilo aún no se hayan cargado.
// load – no solo se cargó el HTML, sino también todos los recursos externos: imágenes, estilos, etc.
// beforeunload/unload – el usuario sale de la pagina.
document.addEventListener("DOMContentLoaded", function() {
    var meses = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
        "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];
    
    // Obtener la fecha actual con el fin de hacer una comparación con el formato de fecha
    var fecha = new Date();
    var dia = fecha.getDate();
    var mes = fecha.getMonth();
    var axo = fecha.getFullYear();
    var fecha_format = dia + ' de ' + meses[mes] + ' de ' + axo;

    // Agregar evento al botón para convertir fecha ingresada
    document.getElementById("btnConvertir").addEventListener("click", convertirFecha);
});

// Función para verificar si un año es bisiesto
function esBisiesto(axo) {
    return (axo % 4 === 0 && (axo % 100 !== 0 || axo % 400 === 0));
}

// Función que convierte una fecha en formato numerico dd/mm/aaaa a un "string"
function convertirFechaTexto(fechaStr) {
    const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
        "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    
    // Validar formato de fecha con expresión regular
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(fechaStr)) return null;
    
    // Convertir fecha en números usando .map y .split
    let [dia, mes, axo] = fechaStr.split("/").map(Number);
    
    // Verificar valores válidos
    if (mes < 1 || mes > 12 || dia < 1 || axo < 1) return null;
    
    // Definir cantidad de días por mes aproximadamente...
    let diasMeses = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    
    // Ajustar febrero si es año bisiesto
    if (esBisiesto(axo)) {
        diasMeses[1] = 29;
    }
    
    // Validar si el día es correcto
    if (dia > diasMeses[mes - 1]) return null;
    
    return `La fecha es: ${dia} de ${meses[mes - 1]} de ${axo}`;
}

// Función que obtiene la fecha ingresada y la convierte a texto/"string"
function convertirFecha() {
    // Utilizamos input y document. para obtener el valor, es decir, la fecha que agregaron
    const input = document.getElementById("fechaIngresada").value;
    //ponerla en resultado para mandarla a convertirla en texto
    const resultado = convertirFechaTexto(input);
    //de lo contrario, poner null
    document.getElementById("resultado").textContent = resultado || "null";
}
